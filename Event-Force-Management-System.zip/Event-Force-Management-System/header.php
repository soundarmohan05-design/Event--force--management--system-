<?php require_once __DIR__ . '/functions.php'; ?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= isset($page_title) ? e($page_title) : 'Event Force Management System' ?></title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<header class="topbar">
  <a class="brand" href="index.php">Event Force <span>Management</span></a>
  <nav>
    <a href="index.php">Home</a>
    <a href="events.php">Events</a>
    <a href="book.php">Book Event</a>
    <?php if (!empty($_SESSION['admin_id'])): ?>
      <a href="dashboard.php">Dashboard</a>
      <a href="logout.php">Logout</a>
    <?php else: ?>
      <a href="login.php">Admin</a>
    <?php endif; ?>
  </nav>
</header>
<main class="container">
<?php show_flash(); ?>
