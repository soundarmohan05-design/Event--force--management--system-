</main>
<footer class="footer">Event Force Management System · College Mini Project</footer>
</body>
</html>
