<?php
require_once 'config.php';
$page_title = 'Home | Event Force';
require 'header.php';
$result = $conn->query("SELECT id, title, category, event_date, venue, price FROM events WHERE event_date >= CURDATE() ORDER BY event_date ASC LIMIT 3");
?>
<section class="hero">
  <div>
    <p class="eyebrow">PLAN · ORGANIZE · CELEBRATE</p>
    <h1>Make every event<br><span>memorable.</span></h1>
    <p class="lead">Manage events, discover upcoming occasions, and book your place in a few simple steps.</p>
    <a class="btn" href="events.php">Explore Events</a>
    <a class="btn btn-outline" href="book.php">Book an Event</a>
  </div>
  <div class="hero-card"><div class="hero-icon">✦</div><h3>Your moments matter</h3><p>One simple place for event planning and bookings.</p></div>
</section>
<section class="section-heading"><div><p class="eyebrow">WHAT'S NEXT</p><h2>Upcoming events</h2></div><a href="events.php">View all →</a></section>
<div class="grid">
<?php if ($result->num_rows): while ($event = $result->fetch_assoc()): ?>
  <article class="event-card">
    <div class="event-banner">✦ <span><?= e($event['category']) ?></span></div>
    <div class="card-body"><h3><?= e($event['title']) ?></h3><p>📅 <?= e($event['event_date']) ?></p><p>📍 <?= e($event['venue']) ?></p><div class="card-bottom"><strong>₹<?= number_format((float)$event['price'], 2) ?></strong><a href="book.php?event_id=<?= (int)$event['id'] ?>">Book →</a></div></div>
  </article>
<?php endwhile; else: ?>
  <div class="empty"><h3>No upcoming events yet</h3><p>Admin can sign in and add events to display them here.</p></div>
<?php endif; ?>
</div>
<?php require 'footer.php'; ?>
