<?php
require_once 'config.php';
$page_title = 'Events | Event Force';
require 'header.php';
$result = $conn->query("SELECT id, title, description, category, event_date, venue, price FROM events ORDER BY event_date ASC");
?>
<div class="page-heading"><p class="eyebrow">DISCOVER</p><h1>All Events</h1><p>Browse available events and reserve your place.</p></div>
<div class="grid">
<?php if ($result->num_rows): while ($event = $result->fetch_assoc()): ?>
<article class="event-card">
  <div class="event-banner">✦ <span><?= e($event['category']) ?></span></div>
  <div class="card-body"><h3><?= e($event['title']) ?></h3><p><?= e($event['description']) ?></p><p>📅 <?= e($event['event_date']) ?></p><p>📍 <?= e($event['venue']) ?></p><div class="card-bottom"><strong>₹<?= number_format((float)$event['price'], 2) ?></strong><a href="book.php?event_id=<?= (int)$event['id'] ?>">Book →</a></div></div>
</article>
<?php endwhile; else: ?>
<div class="empty"><h3>No events available</h3><p>Please check back later.</p></div>
<?php endif; ?>
</div>
<?php require 'footer.php'; ?>
