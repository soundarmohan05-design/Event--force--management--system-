<?php
// Local development database configuration. Change these values for your setup.
$host = 'localhost';
$dbname = 'event_force_management';
$username = 'root';
$password = '';

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
try {
    $conn = new mysqli($host, $username, $password, $dbname);
    $conn->set_charset('utf8mb4');
} catch (Throwable $e) {
    http_response_code(500);
    exit('Database connection failed. Check config.php and import database.sql. Details: ' .
        htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8'));
}
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
