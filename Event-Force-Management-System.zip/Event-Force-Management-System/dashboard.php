<?php
require_once 'config.php';
require_once 'functions.php';
require_admin();
$page_title = 'Dashboard | Event Force';
$event_count = (int)$conn->query('SELECT COUNT(*) c FROM events')->fetch_assoc()['c'];
$booking_count = (int)$conn->query('SELECT COUNT(*) c FROM bookings')->fetch_assoc()['c'];
$pending_count = (int)$conn->query("SELECT COUNT(*) c FROM bookings WHERE status='Pending'")->fetch_assoc()['c'];
$bookings = $conn->query('SELECT b.id, b.customer_name, b.email, b.phone, b.people, b.status, b.created_at, e.title FROM bookings b JOIN events e ON e.id=b.event_id ORDER BY b.created_at DESC');
require 'header.php';
?>
<div class="page-heading"><p class="eyebrow">CONTROL CENTER</p><h1>Admin Dashboard</h1><p>Hello, <?= e($_SESSION['admin_username'] ?? 'Admin') ?>.</p></div>
<div class="stats">
  <div class="stat"><span>Total events</span><strong><?= $event_count ?></strong></div>
  <div class="stat"><span>Total bookings</span><strong><?= $booking_count ?></strong></div>
  <div class="stat"><span>Pending bookings</span><strong><?= $pending_count ?></strong></div>
</div>
<div class="section-heading"><h2>Manage events</h2><a class="btn" href="manage_events.php">Add / Manage Events</a></div>
<div class="table-wrap"><table><thead><tr><th>Booking</th><th>Customer</th><th>Event</th><th>People</th><th>Status</th><th>Action</th></tr></thead><tbody>
<?php if ($bookings->num_rows): while ($b = $bookings->fetch_assoc()): ?>
<tr><td>#<?= (int)$b['id'] ?></td><td><?= e($b['customer_name']) ?><small><?= e($b['email']) ?></small><small><?= e($b['phone']) ?></small></td><td><?= e($b['title']) ?></td><td><?= (int)$b['people'] ?></td><td><span class="status"><?= e($b['status']) ?></span></td><td><form method="post" action="update_booking.php" class="inline-form"><input type="hidden" name="booking_id" value="<?= (int)$b['id'] ?>"><select name="status"><option <?= $b['status']==='Pending'?'selected':'' ?>>Pending</option><option <?= $b['status']==='Confirmed'?'selected':'' ?>>Confirmed</option><option <?= $b['status']==='Cancelled'?'selected':'' ?>>Cancelled</option></select><button class="btn btn-small">Save</button></form></td></tr>
<?php endwhile; else: ?><tr><td colspan="6">No bookings yet.</td></tr><?php endif; ?>
</tbody></table></div>
<?php require 'footer.php'; ?>
