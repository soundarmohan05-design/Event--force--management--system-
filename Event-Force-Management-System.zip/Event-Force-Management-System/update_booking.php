<?php
require_once 'config.php';
require_once 'functions.php';
require_admin();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: dashboard.php');
    exit;
}
$id = filter_input(INPUT_POST, 'booking_id', FILTER_VALIDATE_INT) ?: 0;
$status = $_POST['status'] ?? '';
$allowed = ['Pending', 'Confirmed', 'Cancelled'];
if ($id > 0 && in_array($status, $allowed, true)) {
    $stmt = $conn->prepare('UPDATE bookings SET status = ? WHERE id = ?');
    $stmt->bind_param('si', $status, $id);
    $stmt->execute();
    flash('Booking status updated.');
} else {
    flash('Invalid booking update.', 'error');
}
header('Location: dashboard.php');
exit;
