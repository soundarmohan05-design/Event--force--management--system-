# Event Force Management System

College mini project built with PHP, MySQL, HTML, CSS and JavaScript.

## Features
- Admin login
- Dashboard summary
- Add, view and delete events
- Register customers
- Book an event
- View bookings and update booking status
- Prepared SQL database script

## Requirements
- PHP 8.0+ recommended
- MySQL / MariaDB
- Apache (XAMPP, WAMP, or similar) to run locally

## Setup (XAMPP)
1. Copy the `Event-Force-Management-System` folder into `htdocs`.
2. Start Apache and MySQL in XAMPP.
3. Open phpMyAdmin and import `database.sql`.
4. Open `config.php` and update database settings if needed.
5. Visit `http://localhost/Event-Force-Management-System/` in a browser.

## Demo admin account
- Username: `admin`
- Password: `password`

Change the demo password before using this project beyond a classroom demo. This is a mini-project starter, not a production booking system.

## GitHub upload from iPhone
1. Download and unzip this ZIP in the iPhone Files app.
2. Open https://github.com and create an account.
3. Create a repository named `Event-Force-Management-System`.
4. On GitHub, choose **Add file → Upload files** if available, then select the project files from Files.
5. If GitHub mobile upload is difficult, use Safari's **Request Desktop Website** option. Upload files individually or upload a ZIP only as an archive; GitHub will not run the PHP project from the ZIP.
