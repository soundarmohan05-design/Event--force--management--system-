CREATE DATABASE IF NOT EXISTS event_force_management
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE event_force_management;

CREATE TABLE IF NOT EXISTS admins (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(60) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS events (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(150) NOT NULL,
  category VARCHAR(80) NOT NULL,
  description TEXT NOT NULL,
  event_date DATE NOT NULL,
  venue VARCHAR(200) NOT NULL,
  price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS bookings (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  event_id INT UNSIGNED NOT NULL,
  customer_name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL,
  phone VARCHAR(30) NOT NULL,
  people TINYINT UNSIGNED NOT NULL DEFAULT 1,
  status ENUM('Pending','Confirmed','Cancelled') NOT NULL DEFAULT 'Pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_bookings_event FOREIGN KEY (event_id) REFERENCES events(id)
    ON UPDATE CASCADE ON DELETE RESTRICT
);

-- Demo admin: username=admin, password=password
INSERT INTO admins (username, password_hash)
SELECT 'admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'
WHERE NOT EXISTS (SELECT 1 FROM admins WHERE username='admin');

INSERT INTO events (title, category, description, event_date, venue, price)
SELECT 'Campus Tech Fest', 'Technology', 'A day of innovation, demos and student activities.', DATE_ADD(CURDATE(), INTERVAL 30 DAY), 'College Auditorium', 250.00
WHERE NOT EXISTS (SELECT 1 FROM events WHERE title='Campus Tech Fest');

INSERT INTO events (title, category, description, event_date, venue, price)
SELECT 'Music Evening', 'Entertainment', 'An evening of music, performances and community.', DATE_ADD(CURDATE(), INTERVAL 45 DAY), 'Open Air Stage', 150.00
WHERE NOT EXISTS (SELECT 1 FROM events WHERE title='Music Evening');
