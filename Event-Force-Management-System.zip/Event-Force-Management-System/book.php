<?php
require_once 'config.php';
$page_title = 'Book an Event | Event Force';
$errors = [];
$event_id = filter_input(INPUT_GET, 'event_id', FILTER_VALIDATE_INT) ?: 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $event_id = filter_input(INPUT_POST, 'event_id', FILTER_VALIDATE_INT) ?: 0;
    $name = trim($_POST['customer_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $people = filter_input(INPUT_POST, 'people', FILTER_VALIDATE_INT) ?: 1;

    if ($name === '') $errors[] = 'Please enter your name.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Please enter a valid email.';
    if ($phone === '') $errors[] = 'Please enter your phone number.';
    if ($people < 1 || $people > 50) $errors[] = 'Number of people must be between 1 and 50.';

    $check = $conn->prepare('SELECT id FROM events WHERE id = ?');
    $check->bind_param('i', $event_id);
    $check->execute();
    if (!$check->get_result()->num_rows) $errors[] = 'Please select a valid event.';

    if (!$errors) {
        $stmt = $conn->prepare('INSERT INTO bookings (event_id, customer_name, email, phone, people) VALUES (?, ?, ?, ?, ?)');
        $stmt->bind_param('isssi', $event_id, $name, $email, $phone, $people);
        $stmt->execute();
        flash('Booking submitted successfully! The admin will confirm your booking.');
        header('Location: book.php');
        exit;
    }
}
$events = $conn->query('SELECT id, title, event_date, price FROM events ORDER BY event_date ASC');
require 'header.php';
?>
<div class="form-wrap">
  <p class="eyebrow">SAVE YOUR SPOT</p><h1>Book an Event</h1><p>Fill in your details to submit a booking request.</p>
  <?php if ($errors): ?><div class="alert error"><?php foreach ($errors as $error): ?><div><?= e($error) ?></div><?php endforeach; ?></div><?php endif; ?>
  <form method="post" class="form-card">
    <label>Select event
      <select name="event_id" required>
        <option value="">Choose an event</option>
        <?php while ($event = $events->fetch_assoc()): ?>
        <option value="<?= (int)$event['id'] ?>" <?= $event_id === (int)$event['id'] ? 'selected' : '' ?>><?= e($event['title']) ?> — <?= e($event['event_date']) ?> — ₹<?= number_format((float)$event['price'], 2) ?></option>
        <?php endwhile; ?>
      </select>
    </label>
    <label>Full name<input name="customer_name" value="<?= e($_POST['customer_name'] ?? '') ?>" required maxlength="100"></label>
    <label>Email address<input type="email" name="email" value="<?= e($_POST['email'] ?? '') ?>" required maxlength="150"></label>
    <label>Phone number<input name="phone" value="<?= e($_POST['phone'] ?? '') ?>" required maxlength="30"></label>
    <label>Number of people<input type="number" name="people" min="1" max="50" value="<?= e($_POST['people'] ?? '1') ?>" required></label>
    <button class="btn" type="submit">Submit Booking</button>
  </form>
</div>
<?php require 'footer.php'; ?>
