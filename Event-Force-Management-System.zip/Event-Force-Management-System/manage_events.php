<?php
require_once 'config.php';
require_once 'functions.php';
require_admin();
$page_title = 'Manage Events | Event Force';
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_event'])) {
    $title = trim($_POST['title'] ?? '');
    $category = trim($_POST['category'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $event_date = $_POST['event_date'] ?? '';
    $venue = trim($_POST['venue'] ?? '');
    $price = filter_input(INPUT_POST, 'price', FILTER_VALIDATE_FLOAT);
    if ($title === '' || $category === '' || $description === '' || $event_date === '' || $venue === '' || $price === false || $price < 0) {
        $errors[] = 'Please complete every field with valid information.';
    } else {
        $stmt = $conn->prepare('INSERT INTO events (title, category, description, event_date, venue, price) VALUES (?, ?, ?, ?, ?, ?)');
        $stmt->bind_param('sssssd', $title, $category, $description, $event_date, $venue, $price);
        $stmt->execute();
        flash('Event added successfully.');
        header('Location: manage_events.php');
        exit;
    }
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_event'])) {
    $id = filter_input(INPUT_POST, 'event_id', FILTER_VALIDATE_INT) ?: 0;
    $stmt = $conn->prepare('DELETE FROM events WHERE id = ?');
    $stmt->bind_param('i', $id);
    try {
        $stmt->execute();
        flash('Event deleted if it had no bookings.');
    } catch (mysqli_sql_exception $e) {
        flash('This event has bookings, so it cannot be deleted.', 'error');
    }
    header('Location: manage_events.php');
    exit;
}
$events = $conn->query('SELECT id, title, category, event_date, venue, price FROM events ORDER BY event_date ASC');
require 'header.php';
?>
<div class="page-heading"><p class="eyebrow">ADMIN AREA</p><h1>Manage Events</h1><p>Add new events or review the current event list.</p></div>
<?php if ($errors): ?><div class="alert error"><?php foreach($errors as $error): ?><div><?= e($error) ?></div><?php endforeach; ?></div><?php endif; ?>
<div class="form-wrap">
<form method="post" class="form-card">
<h2>Add an event</h2>
<label>Event title<input name="title" required maxlength="150"></label>
<label>Category<input name="category" placeholder="Wedding, Birthday, Conference..." required maxlength="80"></label>
<label>Description<textarea name="description" required rows="3"></textarea></label>
<label>Date<input type="date" name="event_date" required></label>
<label>Venue<input name="venue" required maxlength="200"></label>
<label>Price (INR)<input type="number" name="price" min="0" step="0.01" required></label>
<button class="btn" name="add_event" value="1">Add Event</button>
</form>
</div>
<h2>Current events</h2>
<div class="table-wrap"><table><thead><tr><th>Event</th><th>Category</th><th>Date</th><th>Venue</th><th>Price</th><th>Action</th></tr></thead><tbody>
<?php if ($events->num_rows): while($event = $events->fetch_assoc()): ?>
<tr><td><?= e($event['title']) ?></td><td><?= e($event['category']) ?></td><td><?= e($event['event_date']) ?></td><td><?= e($event['venue']) ?></td><td>₹<?= number_format((float)$event['price'],2) ?></td><td><form method="post" onsubmit="return confirm('Delete this event?')"><input type="hidden" name="event_id" value="<?= (int)$event['id'] ?>"><button class="btn btn-danger btn-small" name="delete_event" value="1">Delete</button></form></td></tr>
<?php endwhile; else: ?><tr><td colspan="6">No events added yet.</td></tr><?php endif; ?>
</tbody></table></div>
<?php require 'footer.php'; ?>
